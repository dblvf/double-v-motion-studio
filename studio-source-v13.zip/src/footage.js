import {Input,UrlSource,ALL_FORMATS,CanvasSink} from 'mediabunny';
export const footageStyles=['auto','night','energy'];
const videos=new Map(),pending=new Map(),frames=new Map();
let exporting=false;
export function setFootageFrame(style,frame){frames.set(style,frame);}
export function footageFrame(style){return exporting?frames.get(style):videos.get(style)||frames.get(style);}
export function loadFootage(style){
 if(!footageStyles.includes(style))return Promise.resolve();
 if(pending.has(style))return pending.get(style);
 const promise=new Promise((resolve,reject)=>{const v=document.createElement('video');v.muted=true;v.loop=true;v.playsInline=true;v.preload='auto';v.onloadeddata=()=>{videos.set(style,v);resolve(v)};v.onerror=()=>reject(new Error('La vidéo de ce thème ne charge pas. Vérifie ta connexion puis sélectionne à nouveau le thème.'));v.src=`media/${style}.mp4`;v.load();});pending.set(style,promise);promise.catch(()=>pending.delete(style));return promise;
}
export async function activateFootage(style){for(const v of videos.values())v.pause();const v=await loadFootage(style);if(v){v.currentTime=0;await v.play().catch(()=>{});}}
export async function prepareFootageExport(scenes,duration,fps){
 const styles=[...new Set(scenes.map(s=>s.kind.split('_')[1]).filter(s=>footageStyles.includes(s)))];
 const inputs=[],streams=[];exporting=true;for(const v of videos.values())v.pause();
 try{for(const style of styles){const input=new Input({source:new UrlSource(`media/${style}.mp4`),formats:ALL_FORMATS});inputs.push(input);const track=await input.getPrimaryVideoTrack();if(!track||!await track.canDecode())throw new Error('Impossible de décoder la vidéo de ce thème dans ce navigateur. Essaie Chrome ou Edge.');const d=await track.computeDuration();const sink=new CanvasSink(track,{poolSize:2});const times=Array.from({length:Math.floor(duration*fps)},(_,f)=>(f/fps)%d);streams.push({style,iterator:sink.canvasesAtTimestamps(times)});}
 return {async frame(){for(const s of streams){const {value}=await s.iterator.next();if(!value)throw new Error('Une image du fond vidéo n’a pas pu être décodée.');frames.set(s.style,value.canvas);}},async close(){for(const s of streams)await s.iterator.return();for(const i of inputs)i.dispose();exporting=false;frames.clear();}};
 }catch(e){for(const i of inputs)i.dispose();exporting=false;throw e;}
}
export function fillFootage(c,source,x,y,w,h,focal=.5){if(!source)return false;const iw=source.videoWidth||source.width,ih=source.videoHeight||source.height;if(!iw||!ih)return false;const k=Math.max(w/iw,h/ih);c.drawImage(source,x+(w-iw*k)*focal,y+(h-ih*k)/2,iw*k,ih*k);return true;}
