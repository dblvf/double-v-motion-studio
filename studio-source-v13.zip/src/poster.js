import {fillFootage} from './footage.js';
export const socialDefaults={instagram:{enabled:true,handle:'Doublev4902'},youtube:{enabled:true,handle:'doublev_off'},tiktok:{enabled:true,handle:'double__v1'}};
export function socialRows(socials){return Object.keys(socialDefaults).filter(k=>socials[k]?.enabled).map(k=>({key:k,handle:socials[k].handle||socialDefaults[k].handle}));}
function label(c,t,x,y,size,color='#fff',weight=600){c.font=`${weight} ${size}px StudioSans`;c.fillStyle=color;c.textAlign='center';c.fillText(t,x,y);}
function fitted(c,t,x,y,max,size,color,weight=600){c.font=`${weight} ${size}px StudioSans`;label(c,t,x,y,Math.min(size,size*max/Math.max(1,c.measureText(t).width)),color,weight);}
function heading(c,t,width,y,color){let size=78,lines=[];while(size>=18){c.font=`800 ${size}px StudioSans`;lines=[];let row='';for(const word of t.toUpperCase().split(/\s+/)){if(c.measureText((row+' '+word).trim()).width>width&&row){lines.push(row);row=word}else row=(row+' '+word).trim();}lines.push(row);if(lines.length<=3&&lines.every(l=>c.measureText(l).width<=width))break;size-=2;}for(let i=0;i<lines.length;i++)fitted(c,lines[i],540,y+i*size*1.12,width,size,color,800);return lines.length*size*1.12;}
export function drawSocialIcon(c,key,x,y,size,color){c.save();c.translate(x,y);c.scale(size/32,size/32);c.strokeStyle=color;c.fillStyle=color;c.lineWidth=2.2;c.lineCap='round';if(key==='instagram'){c.beginPath();c.roundRect(3,3,26,26,7);c.stroke();c.beginPath();c.arc(16,16,6.2,0,Math.PI*2);c.stroke();c.beginPath();c.arc(24,8.5,1.5,0,Math.PI*2);c.fill();}else if(key==='youtube'){c.beginPath();c.roundRect(1,6,30,21,6);c.fill();c.fillStyle='#09090c';c.beginPath();c.moveTo(13,11);c.lineTo(22,16.5);c.lineTo(13,22);c.fill();}else{for(const [dx,dy,col]of [[-1,1,'#25f4ee'],[1,-1,'#fe2c55'],[0,0,color]]){c.save();c.translate(dx,dy);c.fillStyle=col;c.beginPath();c.moveTo(18,3);c.lineTo(23,3);c.bezierCurveTo(23,8,26,10,30,10);c.lineTo(30,15);c.bezierCurveTo(27,15,24,14,23,13);c.lineTo(23,23);c.bezierCurveTo(23,34,6,34,6,23);c.bezierCurveTo(6,17,11,14,16,16);c.lineTo(16,21);c.bezierCurveTo(10,18,9,27,15,27);c.bezierCurveTo(17,27,18,25,18,23);c.closePath();c.fill();c.restore();}}c.restore();}
export function drawPoster(c,w,h,p,bg,cover,socials){
 c.save();c.scale(w/1080,h/1350);const light=p.style==='minimal',ink=light?'#181818':'#fff',accent=({night:'#bfd1ef',energy:'#ffb17b',auto:'#f5a8cf',cinema:'#e9c893',motion:'#e8e8eb',minimal:'#54544d'})[p.style]||'#fff';
 c.fillStyle=light?'#efede5':'#08090c';c.fillRect(0,0,1080,1350);
 if(bg&&!light){fillFootage(c,bg,0,0,1080,1350);const g=c.createLinearGradient(0,0,0,1350);g.addColorStop(0,'#06070b33');g.addColorStop(.4,'#06070b22');g.addColorStop(.65,'#06070bd9');g.addColorStop(1,'#06070bf5');c.fillStyle=g;c.fillRect(0,0,1080,1350);}
 c.strokeStyle=light?'#aaa99f':'#ffffff45';c.lineWidth=1;c.beginPath();c.moveTo(76,152);c.lineTo(1004,152);c.stroke();
 fitted(c,p.artist.toUpperCase(),540,110,900,37,ink,800);
 label(c,'NOUVELLE SORTIE',540,220,17,accent,500);
 if(cover){c.save();c.shadowColor='#00000055';c.shadowBlur=45;fillFootage(c,cover,365,280,350,350);c.restore();}
 else{label(c,p.style==='night'?'APRÈS MINUIT.':p.style==='energy'?'LE SON PREND SA PLACE.':p.style==='auto'?'TOUTES LES NUANCES.':'MES TEXTES. MA VÉRITÉ.',540,560,18,accent,500);}
 heading(c,p.title,900,752,ink);
 label(c,'DISPONIBLE MAINTENANT',540,1030,22,accent,600);
 const rows=socialRows(socials),gap=57,start=1160-(rows.length-1)*gap/2;
 rows.forEach((row,i)=>{c.font='500 24px StudioSans';const handle=row.handle.replace(/^@/,'');const width=Math.min(770,c.measureText(handle).width),total=36+18+width,x=(1080-total)/2,y=start+i*gap;drawSocialIcon(c,row.key,x,y-26,32,ink);c.textAlign='left';c.font=`500 ${Math.min(24,24*770/Math.max(1,c.measureText(handle).width))}px StudioSans`;c.fillStyle=ink;c.fillText(handle,x+54,y);});
 c.restore();
}
const loaded=new Map();
export async function posterBackground(style){const file=({night:'poster-night.jpg',auto:'poster-auto.jpg',energy:'poster-energy.jpg',cinema:'poster-energy.jpg',motion:'poster-night.jpg'})[style];if(!file)return null;if(loaded.has(file))return loaded.get(file);const promise=new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>reject(new Error('Le décor de l’affiche ne charge pas. Réessaie après avoir vérifié ta connexion.'));im.src=`media/${file}`;});loaded.set(file,promise);promise.catch(()=>loaded.delete(file));return promise;}
