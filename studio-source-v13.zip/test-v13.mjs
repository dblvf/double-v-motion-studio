import {createCanvas,GlobalFonts,loadImage} from '@napi-rs/canvas';
import {drawPoster,socialRows,socialDefaults} from './src/poster.js';
import {setFootageFrame} from './src/footage.js';
import {draw,storyboard} from './src/engine.js';
import fs from 'node:fs';import assert from 'node:assert/strict';import {execFileSync} from 'node:child_process';
GlobalFonts.registerFromPath('dist/fonts/studio-regular.ttf','StudioSans');GlobalFonts.registerFromPath('dist/fonts/studio-bold.ttf','StudioSans');fs.mkdirSync('../qa-v13',{recursive:true});
const p={title:'Celui que t’as oublié',artist:'DOUBLE-V',dateLabel:'21 octobre 2026',releasePast:true},a={duration:15,start:0,env:Array(1500).fill(.4),bass:Array(1500).fill(.4)};
const sheet=createCanvas(1500,1250),ctx=sheet.getContext('2d');
for(const [i,style]of ['night','energy','auto'].entries()){
 execFileSync('ffmpeg',['-v','error','-y','-ss','2','-i',`dist/media/${style}.mp4`,'-frames:v','1',`../qa-v13/${style}-frame.jpg`]);setFootageFrame(style,await loadImage(`../qa-v13/${style}-frame.jpg`));
 const c=createCanvas(500,889);draw(c.getContext('2d'),500,889,2,{...p,style},a,storyboard(a,style));ctx.drawImage(c,i*500,0,500,889);
 const poster=createCanvas(540,675);drawPoster(poster.getContext('2d'),540,675,{...p,style},await loadImage(`dist/media/poster-${style}.jpg`),null,socialDefaults);fs.writeFileSync(`../qa-v13/poster-${style}.png`,poster.toBuffer('image/png'));ctx.drawImage(poster,i*500+110,900,280,350);
}
for(let mask=0;mask<8;mask++){const socials=Object.fromEntries(Object.entries(socialDefaults).map(([k,v],i)=>[k,{...v,enabled:!!(mask&(1<<i))}]));assert.equal(socialRows(socials).length,mask.toString(2).replace(/0/g,'').length);const c=createCanvas(540,675);drawPoster(c.getContext('2d'),540,675,{...p,style:'minimal'},null,null,socials);fs.writeFileSync(`../qa-v13/socials-${mask}.png`,c.toBuffer('image/png'));}
fs.writeFileSync('../qa-v13/contact.png',sheet.toBuffer('image/png'));console.log('PASS: video-backed compositions and all eight social selections render.');
