import fs from 'node:fs';
fs.copyFileSync('dist/style.css','dist/studio-v13.css');
