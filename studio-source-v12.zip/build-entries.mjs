import fs from 'node:fs';
fs.copyFileSync('dist/style.css','dist/studio-v12.css');
