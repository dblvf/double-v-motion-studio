import {directionStoryboard,drawDirection,directionNames} from './directions.js';
import {drawMotion,motionBounds} from './motion.js';
export const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
export const ease=x=>1-Math.pow(1-clamp(x),3);
export function analyze(channels,sr,duration,requested=20,manual=null,variant=0){
 const hop=Math.round(sr*.02), n=channels[0].length, energy=[],bass=[],flux=[];let low=0,prev=0;
 for(let pos=0;pos<n;pos+=hop){let sum=0,lo=0;for(let i=pos;i<Math.min(n,pos+hop);i++){let x=0;for(const c of channels)x+=c[i]/channels.length;low+=.018*(x-low);sum+=x*x;lo+=low*low;}const e=Math.sqrt(sum/hop),b=Math.sqrt(lo/hop);energy.push(e);bass.push(b);flux.push(Math.max(0,e-prev)+Math.max(0,b-(bass[bass.length-2]||0))*2);prev=e;}
 const max=Math.max(.0001,...energy), bm=Math.max(.0001,...bass);const env=energy.map(x=>x/max),be=bass.map(x=>x/bm);let peaks=[];
 for(let i=8;i<flux.length-8;i++){let avg=0;for(let j=i-8;j<i+8;j++)avg+=flux[j]/16;if(flux[i]>avg*1.65&&flux[i]>.008&&flux[i]>=flux[i-1]&&flux[i]>flux[i+1]&&(!peaks.length||i*.02-peaks.at(-1)>.24))peaks.push(i*.02);}
 let votes=Array(161).fill(0);for(let i=0;i<peaks.length;i++)for(let j=i+1;j<Math.min(i+5,peaks.length);j++){let bpm=60/(peaks[j]-peaks[i]);while(bpm<70)bpm*=2;while(bpm>180)bpm/=2;votes[Math.round(bpm)-40]++;}let bpm=peaks.length>3?votes.indexOf(Math.max(...votes))+40:null;
 let len=Math.min(duration,requested||((bpm&&bpm>130)?16:20));let start=0;
 if(manual!==null)start=clamp(manual,0,Math.max(0,duration-len));else{let candidates=[];for(let t=0;t<=duration-len;t+=.5){let a=Math.floor(t/.02), count=Math.floor(len/.02),mean=0,varE=0;for(let j=a;j<a+count;j++){mean+=env[j]/count;varE+=Math.abs((env[j]||0)-(env[j-1]||0))/count;}let intro=env.slice(a,a+50).reduce((s,x)=>s+x,0)/50; candidates.push({t,score:mean+varE*.7+(mean-intro)*.15});}candidates.sort((a,b)=>b.score-a.score);const choices=[];for(const c of candidates)if(choices.every(x=>Math.abs(x.t-c.t)>len*.5))choices.push(c);start=choices[variant%Math.max(1,Math.min(choices.length,3))]?.t||0;const near=peaks.filter(x=>Math.abs(x-start)<.4).sort((a,b)=>Math.abs(a-start)-Math.abs(b-start))[0];if(near!==undefined)start=clamp(near,0,duration-len);}
 return {env,bass:be,peaks,bpm,start,duration:len,sourceDuration:duration,silent:max<.001};
}
export function storyboard(a,style='auto',variant=0){
 if(['auto','night','cinema','energy','minimal'].includes(style))return directionStoryboard(a,style);
 if(style!=='classic'){const b=motionBounds(a);return ['motionSearch','motionProfile','motionCover','motionChat','motionFinal'].map((kind,i)=>({kind,start:b[i],end:b[i+1],style}));}
 const energetic=a.bpm&&a.bpm>130;let resolved=style==='auto'?(energetic?'energy':'night'):style;
 const sets=resolved==='minimal'?[['reveal','visual','final']]:resolved==='energy'?[['social','visual','phone','final'],['visual','desktop','reveal','final']]:[['desktop','phone','visual','final'],['phone','social','reveal','final'],['desktop','social','visual','final']];
 const kinds=sets[variant%sets.length], ratios=kinds.length===3?[0,.32,.73,1]:[0,.24,.48,.76,1];let bounds=ratios.map(r=>r*a.duration);
 for(let i=1;i<bounds.length-1;i++){const hits=a.peaks.map(p=>p-a.start).filter(p=>Math.abs(p-bounds[i])<.45);if(hits.length)bounds[i]=hits.sort((x,y)=>Math.abs(x-bounds[i])-Math.abs(y-bounds[i]))[0];}
 return kinds.map((kind,i)=>({kind,start:bounds[i],end:bounds[i+1],style:resolved}));
}
export const names={...directionNames,motionSearch:'Motion · Recherche',motionProfile:'Motion · Profil',motionCover:'Nouvelle publication → pochette',motionChat:'Motion · Conversation',motionFinal:'Motion · Révélation',desktop:'Écran de nuit',phone:'Notification & Notes',visual:'Pulsation',social:'La première écoute',reveal:'Révélation',final:'Annonce de sortie'};
function box(c,x,y,w,h,r,fill,stroke){c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=1.3;c.stroke();}}
function text(c,s,x,y,size=22,color='#fff',weight=500,align='left'){c.font=`${weight} ${size}px StudioSans`;c.fillStyle=color;c.textAlign=align;c.fillText(s,x,y);}
function wrap(c,s,x,y,max,size=52,color='#fff',lines=3){const words=String(s).split(/\s+/);let rows=[],row='';c.font=`800 ${size}px StudioSans`;for(let word of words){while(c.measureText(word).width>max&&word.length>1){let k=1;while(k<word.length&&c.measureText(word.slice(0,k+1)).width<max)k++;if(row){rows.push(row);row='';}rows.push(word.slice(0,k));word=word.slice(k);}if(c.measureText((row+' '+word).trim()).width>max&&row){rows.push(row);row=word;}else row=(row+' '+word).trim();}if(row)rows.push(row);if(rows.length>lines&&size>22)return wrap(c,s,x,y,max,size-3,color,lines);rows.slice(0,lines).forEach((r,i)=>text(c,r,x,y+i*size*1.12,size,color,800,'center'));return Math.min(rows.length,lines)*size*1.12;}
function cover(c,img,x,y,s,t,accent){c.save();box(c,x,y,s,s,8,'#17191f');c.clip();if(img){let w=img.width||img.naturalWidth,h=img.height||img.naturalHeight,k=Math.max(s/w,s/h);c.drawImage(img,x+(s-w*k)/2,y+(s-h*k)/2,w*k,h*k);}else{const g=c.createLinearGradient(x,y,x+s,y+s);g.addColorStop(0,'#222530');g.addColorStop(.6,'#0a0b10');g.addColorStop(1,accent);c.fillStyle=g;c.fillRect(x,y,s,s);c.translate(x+s/2,y+s/2);c.rotate(-.16+t*.025);text(c,'DOUBLE-V',0,s*.06,s*.15,'#dedde6',900,'center');for(let j=0;j<9;j++){c.strokeStyle='#ffffff12';c.strokeRect(-s*.45+j*10,-s*.45+j*10,s*.9-j*20,s*.9-j*20);}}c.restore();}
function spectrum(c,a,t,x,y,w,h,accent){const idx=Math.floor((a.start+t)/.02);for(let j=0;j<48;j++){const v=a.env[Math.max(0,idx-24+j)]||.03;const v2=a.bass[Math.max(0,idx-24+j)]||0;const bh=8+(v*.6+v2*.4)*h*(.5+.5*Math.sin(j*1.7)**2);box(c,x+j*w/48,y-bh/2,w/48*.55,bh,3,j%7===0?accent:'#d9dce7');}}
export function draw(c,w,h,t,p,a,scenes,img){
 const selected=scenes.find(s=>t>=s.start&&t<s.end)||scenes.at(-1);if(selected?.kind.startsWith('art_'))return drawDirection(c,w,h,t,p,a,scenes,img);if(selected?.kind.startsWith('motion'))return drawMotion(c,w,h,t,p,a,img);
 c.save();c.fillStyle='#07080c';c.fillRect(0,0,w,h);const portrait=h>w;const scale=portrait?w/600:Math.min(w/1000,h/800);c.translate(w/2,h/2);c.scale(scale,scale);const W=w/scale,H=h/scale;const accent=p.style==='energy'?'#c5ff72':p.style==='minimal'?'#d7dbe6':'#b9a4ff';const idx=Math.floor((a.start+t)/.02),beat=a.bass[idx]||0;
 const glow=c.createRadialGradient(0,-80,5,0,-80,Math.max(W,H)*.65);glow.addColorStop(0,p.style==='energy'?`rgba(88,114,47,${.15+beat*.08})`:`rgba(85,68,125,${.22+beat*.1})`);glow.addColorStop(1,'#07080c');c.fillStyle=glow;c.fillRect(-W/2,-H/2,W,H);
 for(let k=0;k<27;k++){let x=Math.sin(k*128.1)*W*.5,y=((k*61+t*(3+k%4))%H)-H/2;c.fillStyle='#ffffff15';c.fillRect(x,y,1.3,1.3);}
 text(c,p.artist.toUpperCase(),0,-H/2+Math.max(80,H*.11),18,'#c7c9d3',700,'center');
 const scene=scenes.find(s=>t>=s.start&&t<s.end)||scenes.at(-1);let local=t-scene.start, len=scene.end-scene.start,u=local/len;let transition=Math.min(ease(local/.5),scene.kind==='final'?1:ease((len-local)/.35));
 c.save();c.globalAlpha=transition;c.translate(Math.sin(t*.7)*3, (1-ease(local/.7))*22);c.scale(1+u*.025+beat*.006,1+u*.025+beat*.006);
 if(scene.kind==='desktop'){
 const zoom=(portrait?.87:1)+ease(clamp((u-.55)/.45))*.13;c.scale(zoom,zoom);c.transform(1,.012*Math.sin(t),.018,1,0,0);
 box(c,-255,-222,510,335,14,'#13161b','#4b4e58');box(c,-243,-210,486,304,7,'#0d1019');
 c.fillStyle='#ffffff06';c.fillRect(-243,-210,486,30);for(let i=0;i<3;i++)box(c,-227+i*14,-199,6,6,3,['#b75c60','#b6a06a','#6f9f8b'][i]);text(c,'DOUBLE-V / STUDIO',-174,-192,10,'#a1a5b1');
 cover(c,img,-206,-143,150,t,accent);text(c,'PROCHAINE SORTIE',-35,-126,12,accent,700);let titleHeight=wrap(c,p.title,90,-87,240,27,'#fff',3);text(c,p.artist,90,-87+titleHeight+15,13,'#a5a8b5',500,'center');spectrum(c,a,t,-210,54,420,32,accent);
 box(c,-20,114,40,55,4,'#252831');box(c,-100,163,200,8,4,'#41434c');const g=c.createLinearGradient(0,180,0,250);g.addColorStop(0,'#24232b');g.addColorStop(1,'#08090c');c.fillStyle=g;c.fillRect(-W/2,180,W,150);
 if(u>.27){let b=ease((u-.27)/.18);c.save();c.translate(0,(1-b)*-30);c.globalAlpha*=b;box(c,-145,-295,290,62,12,'#e9eaf0');text(c,'♪  MUSIQUE',-128,-274,10,'#777b85',700);text(c,'DOUBLE-V • Nouveau son',-128,-250,15,'#1d2028',700);c.restore();}
 text(c,'UNE NOUVELLE FRÉQUENCE.',0,255,18,'#d1d3df',600,'center');
 }else if(scene.kind==='phone'){
 c.rotate(Math.sin(t*.5)*.012);box(c,-157,-303,314,610,42,'#060708','#646771');box(c,-147,-293,294,590,34,'#191a25');box(c,-48,-284,96,23,12,'#030405');text(c,'00:00',-124,-257,12,'#d9dae2',700);text(c,'▰',113,-257,15,'#d9dae2',700);
 const note=ease((u-.35)/.18);c.save();c.globalAlpha*=1-note;text(c,'00:00',0,-140,72,'#f8f8fc',500,'center');text(c,'Le prochain chapitre.',0,-103,16,'#bec1d0',500,'center');let ny=-30+(1-ease(u/.25))*45;box(c,-130,ny,260,105,20,'#e5e5ed');text(c,'♪  DOUBLE-V',-113,ny+26,13,'#686775',700);text(c,'Un nouveau son arrive.',-113,ny+54,17,'#19191f',700);text(c,'Glisser pour découvrir',-113,ny+81,12,'#6f6c7b');c.restore();
 c.save();c.globalAlpha*=note;c.translate((1-note)*70,0);text(c,'‹ Notes',-124,-211,17,'#e6c367',600);text(c,'Ne pas déranger  ☾',0,-169,13,'#a0a1b1',500,'center');text(c,'Prochain son',0,-108,26,'#fafafa',800,'center');wrap(c,p.title,0,-55,235,31,'#fff',4);box(c,-121,133,242,74,15,'#2a2936');text(c,'RAPPEL • SORTIE',-104,158,11,accent,700);text(c,p.dateLabel,0,187,19,'#fff',700,'center');c.restore();box(c,-50,282,100,4,2,'#eee');
 }else if(scene.kind==='social'){
 box(c,-218,-267,436,530,20,'#111319','#32353d');text(c,'●  '+p.artist,-190,-224,20,'#fff',700);text(c,'Première écoute',-190,-198,13,'#969ba9');cover(c,img,-190,-170,380,t,accent);const z=ease(u/.9);box(c,-190,221,380,3,2,'#454752');box(c,-190,221,Math.max(2,380*z),3,2,accent);text(c,'▷',-185,249,18,'#fff');text(c,'NOUVEAU MORCEAU',-150,247,12,'#ddd',600);
 }else if(scene.kind==='visual'){
 c.save();c.rotate(Math.sin(t*.35)*.04);const s=portrait?330:300;cover(c,img,-s/2,-s/2-70,s,t,accent);c.restore();spectrum(c,a,t,-220,portrait?192:170,440,80,accent);wrap(c,p.title,0,portrait?294:255,480,35,'#fff',2);
 }else if(scene.kind==='reveal'){
 c.save();c.rotate(-.06+u*.12);cover(c,img,-175,-240,350,t,accent);c.restore();wrap(c,p.title,0,195,470,48,'#fff',3);
 }else{
 const s=portrait?235:190;cover(c,img,-s/2,portrait?-305:-260,s,t,accent);text(c,'LE PROCHAIN CHAPITRE',0,portrait?-28:-35,13,accent,700,'center');const hh=wrap(c,p.title,0,portrait?33:24,portrait?470:700,portrait?51:54,'#fff',3);let yy=(portrait?33:24)+hh+34;text(c,p.releasePast?'DISPONIBLE MAINTENANT':'DISPONIBLE LE',0,yy,14,'#9fa3b1',600,'center');text(c,p.dateLabel,0,yy+41,31,'#fff',700,'center');
 }
 c.restore();text(c,'DOUBLE-V  /  NOUVELLE SORTIE',0,H/2-(portrait?Math.max(125,H*.15):40),11,'#7d8190',600,'center');c.restore();
}
