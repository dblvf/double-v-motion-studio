// Shared, sample-accurate envelope. End exactly at zero without touching source audio.
export function audioGain(time,duration){
 const fade=Math.min(2.2,duration*.3), remaining=Math.max(0,duration-time);
 const x=Math.min(1,remaining/fade), smooth=x*x*(3-2*x);
 return Math.min(1,Math.max(0,time)/.035)*smooth;
}
