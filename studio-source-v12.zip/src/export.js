import {Output,BufferTarget,Mp4OutputFormat,VideoSampleSource,VideoSample,AudioSampleSource,AudioSample,canEncodeVideo,canEncodeAudio} from 'mediabunny';
import {registerAacEncoder} from '@mediabunny/aac-encoder';
import {draw} from './engine.js';
import {audioGain} from './audio-envelope.js';
export async function exportVideo({canvas,p,a,scenes,img,channels,sampleRate,onProgress=()=>{},signal,rawFrames=false}){
 const fps=p.fps||30,w=canvas.width,h=canvas.height;
 if(!await canEncodeVideo('avc',{width:w,height:h,bitrate:6000000}))throw new Error('Ce navigateur ne propose pas l’encodage H.264. Ouvre le studio dans Chrome ou Edge récent sur ton ordinateur.');
 if(!await canEncodeAudio('aac',{sampleRate,numberOfChannels:channels.length}))registerAacEncoder();
 const target=new BufferTarget(),out=new Output({format:new Mp4OutputFormat({fastStart:'in-memory'}),target});
 const video=new VideoSampleSource({codec:'avc',bitrate:6000000,keyFrameInterval:2});const audio=new AudioSampleSource({codec:'aac',bitrate:192000});out.addVideoTrack(video,{frameRate:fps});out.addAudioTrack(audio);await out.start();
 const frames=Math.floor(a.duration*fps), duration=frames/fps,ctx=canvas.getContext('2d'),chunk=Math.round(sampleRate/fps);let audioPos=0;const totalAudio=Math.round(duration*sampleRate),offset=Math.round(a.start*sampleRate);
 try{for(let f=0;f<frames;f++){if(signal?.aborted)throw new Error('Génération annulée.');draw(ctx,w,h,f/fps,p,a,scenes,img);const v=rawFrames?new VideoSample(ctx.getImageData(0,0,w,h).data,{format:'RGBA',codedWidth:w,codedHeight:h,timestamp:f/fps,duration:1/fps}):new VideoSample(canvas,{timestamp:f/fps,duration:1/fps});await video.add(v);v.close();
 const end=Math.min(totalAudio,Math.round((f+1)/fps*sampleRate));if(end>audioPos){const count=end-audioPos,data=new Float32Array(count*channels.length);for(let ch=0;ch<channels.length;ch++)for(let i=0;i<count;i++){let time=(audioPos+i)/sampleRate;let gain=audioGain(time,duration);data[ch*count+i]=(channels[ch][offset+audioPos+i]||0)*gain;}const s=new AudioSample({data,format:'f32-planar',numberOfChannels:channels.length,sampleRate,timestamp:audioPos/sampleRate});await audio.add(s);s.close();audioPos=end;}
 if(f%6===0){onProgress(f/frames);await new Promise(r=>setTimeout(r,0));}}
 video.close();audio.close();onProgress(1);await out.finalize();return new Blob([target.buffer],{type:'video/mp4'});
 }catch(e){await out.cancel().catch(()=>{});throw e;}
}
