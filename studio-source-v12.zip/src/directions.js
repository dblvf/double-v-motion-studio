const clamp=x=>Math.max(0,Math.min(1,x));
const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
export const directionInfo={
 motion:'Motion · Recherche Instagram, vrai profil et pochette en mouvement dans un décor sombre.',
 auto:'Surprise · Collage corail et turquoise, découpes graphiques et pochettes en éventail.',
 night:'Nocturne · Bleu profond, halos violets, disque vinyle et mouvements lents.',
 cinema:'Cinéma · Lumière ambrée, écran panoramique, travelling et générique de sortie.',
 energy:'Énergique · Vert acide et orange, diagonales, mosaïque et typographie sur les impacts.',
 minimal:'Minimal · Papier ivoire, noir, composition éditoriale et mouvements précis.'
};
const sequences={auto:['Découpe colorée','Pochettes en éventail','Collage de sortie'],night:['Éclipse','Vinyle en orbite','Lueur finale'],cinema:['Ouverture cinéma','Travelling sur la pochette','Générique de sortie'],energy:['Impact typographique','Mosaïque rythmique','Affiche électrique'],minimal:['Titre éditorial','Galerie de la pochette','Signature de sortie']};
export const directionNames=Object.fromEntries(Object.entries(sequences).flatMap(([style,names])=>names.map((n,i)=>[`art_${style}_${i}`,n])));
export function directionStoryboard(a,style){const ratios=style==='energy'?[0,.23,.65,1]:style==='cinema'?[0,.29,.68,1]:[0,.27,.65,1];return sequences[style].map((_,i)=>({kind:`art_${style}_${i}`,style,start:ratios[i]*a.duration,end:ratios[i+1]*a.duration}));}
function text(c,s,x,y,size=20,color='#fff',weight=600,align='center'){c.fillStyle=color;c.font=`${weight} ${size}px StudioSans`;c.textAlign=align;c.fillText(String(s),x,y)}
function fit(c,s,x,y,width,size,color,weight=700,align='center'){c.font=`${weight} ${size}px StudioSans`;text(c,s,x,y,Math.min(size,size*width/Math.max(1,c.measureText(s).width)),color,weight,align)}
function title(c,s,x,y,width,height,size,color='#fff',align='center'){
 s=String(s).toUpperCase();let rows=[];
 for(let z=size;z>=9;z--){c.font=`800 ${z}px StudioSans`;rows=[];let row='';for(const word of s.split(/\s+/)){if(c.measureText(word).width>width){rows=[];break}const next=(row+' '+word).trim();if(row&&c.measureText(next).width>width){rows.push(row);row=word}else row=next}if(!rows.length&&!row)continue;if(row)rows.push(row);if(rows.length*z*1.13<=height&&rows.every(r=>c.measureText(r).width<=width)){rows.forEach((r,i)=>text(c,r,x,y+i*z*1.13,z,color,800,align));return rows.length*z*1.13;}}
 fit(c,s,x,y,width,14,color,800,align);return 16;
}
function rect(c,x,y,w,h,color){c.fillStyle=color;c.fillRect(x,y,w,h)}
function line(c,x,y,X,Y,color,width=1){c.strokeStyle=color;c.lineWidth=width;c.beginPath();c.moveTo(x,y);c.lineTo(X,Y);c.stroke()}
function circle(c,x,y,r,color){c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fillStyle=color;c.fill()}
function art(c,img,x,y,s,accent='#ab98ff',rotation=0){c.save();c.translate(x+s/2,y+s/2);c.rotate(rotation);rect(c,-s/2,-s/2,s,s,'#14121b');c.beginPath();c.rect(-s/2,-s/2,s,s);c.clip();if(img){const iw=img.naturalWidth||img.width,ih=img.naturalHeight||img.height,k=Math.max(s/iw,s/ih);c.drawImage(img,-iw*k/2,-ih*k/2,iw*k,ih*k)}else{const g=c.createLinearGradient(-s/2,-s/2,s/2,s/2);g.addColorStop(0,'#171323');g.addColorStop(1,accent);rect(c,-s/2,-s/2,s,s,g);for(let j=0;j<6;j++)line(c,-s/2,-s/2+j*s/4,s/2,-s/2+j*s/4-s*.35,'#ffffff18');fit(c,'DOUBLE-V',0,s*.035,s*.82,s*.15,'#fff',800)}c.restore()}
function wave(c,a,t,x,y,w,h,color){let idx=Math.floor((a.start+t)/.02);for(let j=0;j<48;j++){const v=a.env[Math.max(0,idx-24+j)]||.05;rect(c,x+j*w/48,y-(3+v*h)/2,w/90,3+v*h,color)}}
function release(c,p,y,color,width=490){text(c,p.releasePast?'DISPONIBLE MAINTENANT':'DISPONIBLE LE',0,y,12,color,500);fit(c,p.dateLabel,0,y+36,width,27,color,700)}
function glow(c,x,y,r,color){const g=c.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'#00000000');rect(c,x-r,y-r,r*2,r*2,g)}
function render(c,W,H,t,p,a,img,style,phase,u){
 const energy=a.bass[Math.floor((a.start+t)/.02)]||0;
 const pos=phase===2?ease(Math.min(1,u*3)):ease(u);const ink='#15171b';
 if(style==='auto'){
  const palette=(p.variant||0)%2?['#ef9dca','#a4f1c6','#172f3b']:['#ff765e','#8bded4','#202640'];const [coral,mint,navy]=palette;
  rect(c,-W/2,-H/2,W,H,phase===1?mint:coral);c.save();c.translate(W*.22,-80);c.rotate(-.23+.07*Math.sin(t*.25));rect(c,-160,-H,320,H*2,navy);c.restore();circle(c,-W*.34,H*.27,170,mint);
  rect(c,-155,-H/2+48,310,38,'#f9f4e8');fit(c,p.artist.toUpperCase(),0,-H/2+73,280,17,ink,800);
  if(phase===0){c.save();c.translate(-15+30*pos,10);c.rotate(-.08+.13*pos);rect(c,-245,-142,490,270,'#f9f4e8');title(c,p.title,0,-45,430,170,65,ink);c.restore();rect(c,-160,221,320,34,'#f9f4e8');text(c,'NOUVEAU MORCEAU',0,244,14,ink,800);line(c,-160,270,160,270,ink,3)}
  if(phase===1){for(let j=-1;j<=1;j++){c.save();c.translate(j*(125+25*pos),j===0?-20:35);c.rotate(j*(.15+.06*pos));art(c,img,-132,-132,264,coral);c.restore()}rect(c,-245,205,490,124,'#f9f4e8');text(c,'DOUBLE-V',0,258,42,navy,800);wave(c,a,t,-185,300,370,26,navy)}
  if(phase===2){c.save();c.translate(0,-100);c.rotate(-.055*(1-pos));rect(c,-139,-139,278,278,'#f9f4e8');art(c,img,-126,-126,252,coral);c.restore();rect(c,-260,81,520,318,'#f9f4e8');title(c,p.title,0,143,470,150,54,ink);release(c,p,328,ink)}
  rect(c,-130,H/2-78,260,29,'#f9f4e8');text(c,'MUSIQUE / DOUBLE-V',0,H/2-58,10,ink,600);
 }else if(style==='night'){
  rect(c,-W/2,-H/2,W,H,'#070b22');glow(c,130*Math.sin(t*.18),-110,460,'#353baf99');glow(c,-190,210,340,'#b549ac40');
  for(let j=0;j<35;j++){const x=Math.sin(j*112.3)*W*.46,y=Math.cos(j*31.7)*H*.43;circle(c,x,y,1+(j%3)*.3,'#acb8e040')}
  fit(c,p.artist.toUpperCase(),0,-H/2+78,450,16,'#b4c9f5');
  if(phase===0){circle(c,0,-70,168,'#7279dc');circle(c,26+pos*35,-85,162,'#0b1232');title(c,p.title,0,180,480,150,51,'#e4eaff');text(c,'UNE NOUVELLE FRÉQUENCE',0,355,11,'#93a5d5')}
  if(phase===1){c.save();c.translate(48,-35);c.rotate(t*.22);circle(c,0,0,181,'#060815');for(let r=70;r<177;r+=7){c.strokeStyle='#27304d';c.lineWidth=1;c.beginPath();c.arc(0,0,r,0,Math.PI*2);c.stroke()}circle(c,0,0,58,'#8777cc');circle(c,0,0,8,'#090d23');c.restore();art(c,img,-222-10*pos,-182,275,'#554e9d',-.035);wave(c,a,t,-220,225,440,45,'#a6bbf5');fit(c,p.title,0,320,470,28,'#dce4fa')}
  if(phase===2){art(c,img,-143,-270,286,'#554e9d');line(c,-35,69,35,69,'#acbaff');title(c,p.title,0,145,480,150,49,'#e5eaff');release(c,p,330,'#c0cef4')}
  text(c,'DOUBLE-V / APRÈS MINUIT',0,H/2-65,10,'#8191bc',500);
 }else if(style==='cinema'){
  rect(c,-W/2,-H/2,W,H,'#120f0b');const g=c.createLinearGradient(-W/2,-H/2,W/2,H/2);g.addColorStop(0,'#4a3022');g.addColorStop(.55,'#1b1713');g.addColorStop(1,'#8b5634');rect(c,-W/2,-H/2,W,H,g);
  glow(c,-W*.3+pos*W*.6,-80,500,'#e0a66633');
  // Fixed letterbox, with content kept inside the safe composition.
  rect(c,-W/2,-H/2,W,Math.max(42,H*.075),'#080807');rect(c,-W/2,H/2-Math.max(42,H*.075),W,Math.max(42,H*.075),'#080807');
  fit(c,p.artist.toUpperCase(),0,-H/2+120,460,14,'#e1c9a6',500);
  if(phase===0){text(c,'DOUBLE-V PRÉSENTE',0,-135,12,'#c4a781',500);line(c,-60,-100,60,-100,'#bb8f5e');title(c,p.title,0,-8,500,185,59,'#f6e9d3');text(c,'UN NOUVEAU MORCEAU',0,252,12,'#c4a781',500)}
  if(phase===1){c.save();c.beginPath();c.rect(-W*.45,-210,W*.9,355);c.clip();if(img){const iw=img.naturalWidth||img.width,ih=img.naturalHeight||img.height,k=Math.max(W*.95/iw,390/ih)*1.1;c.drawImage(img,-iw*k/2+pos*25,-ih*k/2-40,iw*k,ih*k);rect(c,-W/2,-220,W,390,'#1c120744')}else{art(c,null,-310+pos*25,-340,630,'#b8804c')}c.restore();line(c,-W*.45,155,W*.45,155,'#d0ae7a');fit(c,p.title,0,239,490,35,'#f4e4c8');text(c,'LE SON PREND TOUTE LA PLACE.',0,302,11,'#c7ac88',500)}
  if(phase===2){art(c,img,-113,-272,226,'#b8804c');title(c,p.title,0,70,500,150,47,'#f4e4c8');line(c,-160,269,160,269,'#8f7351');release(c,p,307,'#e5cfaa')}
 }else if(style==='energy'){
  const lime='#d6fa49',orange='#ff703e';rect(c,-W/2,-H/2,W,H,'#111411');
  c.save();c.rotate(-.25);rect(c,-W,-H*.33+pos*45,W*2,120,phase===1?orange:lime);rect(c,-W,H*.28-pos*35,W*2,80,phase===1?lime:orange);c.restore();
  fit(c,p.artist.toUpperCase(),0,-H/2+75,440,18,lime,800);
  // Smooth beat envelope gives impact without strobing the full screen.
  const kick=1+Math.min(.045,energy*.045);c.save();c.scale(kick,kick);
  if(phase===0){rect(c,-245,-205,490,460,'#111411');title(c,p.title,-225,-105,450,270,79,'#f4f7e7','left');text(c,'MONTE LE VOLUME',-225,258,20,lime,800,'left');wave(c,a,t,-225,315,450,36,orange)}
  if(phase===1){for(let j=0;j<4;j++){const x=(j%2)*214-211,y=Math.floor(j/2)*214-242;const shift=Math.sin(t*1.4+j)*7;art(c,img,x,y+shift,204,j%2?orange:lime,(j%2?1:-1)*.025)}rect(c,-245,220,490,68,lime);fit(c,p.title,0,265,450,38,ink,800)}
  if(phase===2){art(c,img,-135,-268,270,orange,-.045*(1-pos));title(c,p.title,0,96,485,160,61,lime);rect(c,-250,292,500,97,lime);release(c,p,323,ink,455)}
  c.restore();text(c,'DOUBLE-V / FAIS TOURNER',0,H/2-61,11,lime,700);
 }else{
  rect(c,-W/2,-H/2,W,H,'#efede5');const margin=Math.min(W*.5-45,260);line(c,-margin,-H/2+105,margin,-H/2+105,ink);text(c,'DOUBLE-V',-margin,-H/2+79,15,ink,800,'left');text(c,'MUSIQUE',margin,-H/2+79,10,ink,500,'right');
  if(phase===0){text(c,'NOUVELLE SORTIE',-225,-210,11,'#65655f',500,'left');title(c,p.title,-225,-104+18*(1-pos),450,300,68,ink,'left');line(c,-225,270,-225+450*pos,270,ink,2)}
  if(phase===1){art(c,img,-170,-245+20*(1-pos),340,'#92988d');text(c,'LE PROCHAIN CHAPITRE',-170,150,10,'#666960',500,'left');title(c,p.title,-170,201,340,130,34,ink,'left')}
  if(phase===2){art(c,img,-108,-265,216,'#92988d');title(c,p.title,0,46,455,182,51,ink);line(c,-65,266,65,266,ink);release(c,p,316,ink,450)}
  line(c,-margin,H/2-90,margin,H/2-90,'#aaa99f');text(c,p.artist.toUpperCase(),-margin,H/2-60,11,ink,500,'left');text(c,'ÉDITION MUSICALE',margin,H/2-60,10,'#666960',500,'right');
 }
}
export function drawDirection(c,w,h,t,p,a,scenes,img){
 const selected=scenes.find(s=>t>=s.start&&t<s.end)||scenes.at(-1);const [,style,part]=selected.kind.split('_');const phase=Number(part);if(!sequences[style])return;
 const scale=Math.min(w/600,h/1000),W=w/scale,H=h/scale;
 c.save();c.translate(w/2,h/2);c.scale(scale,scale);
 const local=t-selected.start,len=selected.end-selected.start;const finalTime=Math.min(t,a.duration-Math.min(2,a.duration*.15));
 render(c,W,H,phase===2?finalTime:t,p,a,img,style,phase,clamp(local/len));
 // Outgoing scene on top fades into the new one; no dark gap between shots.
 const i=scenes.indexOf(selected),transition=Math.min(.55,len*.15);
 if(i>0&&local<transition&&scenes[i-1].kind.startsWith('art_')){const prev=scenes[i-1],[,ps,pp]=prev.kind.split('_');c.save();c.globalAlpha=1-ease(local/transition);render(c,W,H,t,p,a,img,ps,Number(pp),1);c.restore()}
 c.restore();
}
