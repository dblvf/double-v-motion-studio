let realProfile=null;
export function setProfileImages(images){realProfile=images;}
// One continuous camera and persistent phone; layers move independently.
const cl=x=>Math.max(0,Math.min(1,x));
const sm=x=>{x=cl(x);return x*x*x*(x*(x*6-15)+10)};
const ramp=(x,a,b)=>sm((x-a)/(b-a));
const lerp=(a,b,t)=>a+(b-a)*t;
function rect(c,x,y,w,h,r,fill,stroke){c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill()}if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke()}}
function tx(c,t,x,y,size=20,color='#fff',weight=700,align='center'){c.font=`${weight} ${size}px StudioSans`;c.fillStyle=color;c.textAlign=align;c.fillText(t,x,y)}
function fitted(c,s,x,y,width,size=24,color='#fff',weight=700){c.font=`${weight} ${size}px StudioSans`;const k=Math.min(1,width/Math.max(1,c.measureText(s).width));tx(c,s,x,y,size*k,color,weight)}
function title(c,s,x,y,width,maxHeight,size=58){const words=String(s).toUpperCase().split(/\s+/);for(let z=size;z>=10;z--){c.font=`800 ${z}px StudioSans`;if(words.some(word=>c.measureText(word).width>width))continue;let rows=[],row='';for(const word of words){const next=(row+' '+word).trim();if(row&&c.measureText(next).width>width){rows.push(row);row=word}else row=next;}if(row)rows.push(row);if(rows.length*z*1.12<=maxHeight){rows.forEach((l,i)=>tx(c,l,x,y+i*z*1.12,z));return;}}fitted(c,String(s).toUpperCase(),x,y,width,12);}
function art(c,img,x,y,s,time,accent){c.save();rect(c,x,y,s,s,10,'#000');c.clip();if(img){const k=Math.max(s/img.width,s/img.height);c.drawImage(img,x+(s-img.width*k)/2,y+(s-img.height*k)/2,img.width*k,img.height*k)}else{const g=c.createLinearGradient(x,y,x+s,y+s);g.addColorStop(0,'#302044');g.addColorStop(.55,'#120e1c');g.addColorStop(1,accent);c.fillStyle=g;c.fillRect(x,y,s,s);fitted(c,'DOUBLE-V',x+s/2,y+s*.55,s*.84,s*.17,'#fff',800);}c.restore();rect(c,x,y,s,s,10,null,'#333');}
function alpha(c,a,fn){if(a<.001)return;c.save();c.globalAlpha*=cl(a);fn();c.restore()}
function wave(c,a,t,x,y,width,height,color){let idx=Math.floor((a.start+t)/.02);for(let j=0;j<36;j++){let e=a.env[Math.max(0,idx-18+j)]||0;const h=4+height*e*(.35+.65*Math.sin(j*2.3)**2);rect(c,x+j*width/36,y-h/2,width/36*.48,h,2,color)}}
function phoneBody(c){c.shadowColor='#000b';c.shadowBlur=38;c.shadowOffsetY=22;rect(c,-157,-303,314,606,40,'#0b0b0b','#767676');c.shadowBlur=0;c.shadowOffsetY=0;rect(c,-151,-297,302,594,35,'#1d1d1d','#292929');rect(c,-145,-291,290,582,30,'#0f0f0f');rect(c,-162,-190,4,55,2,'#767676');rect(c,158,-154,3,66,2,'#767676')}
export function motionBounds(a){let b=[0,.17,.35,.54,.76,1].map(x=>x*a.duration);for(let i=1;i<b.length-1;i++){const hits=a.peaks.map(p=>p-a.start).filter(p=>Math.abs(p-b[i])<Math.min(.35,a.duration*.018));if(hits.length)b[i]=hits.sort((x,y)=>Math.abs(x-b[i])-Math.abs(y-b[i]))[0]}return b}
export function motionState(time,a){
 const hold=Math.min(2,a.duration*.16),holdAt=a.duration-hold;
 const t=Math.min(time,holdAt),b=motionBounds(a);let phase=b.findIndex((v,i)=>i<b.length-1&&t>=v&&t<b[i+1]);if(phase<0)phase=4;
 const stops=[0,.17,.35,.54,.76,1];const end=phase===4?holdAt:b[phase+1];
 const q=lerp(stops[phase],stops[phase+1],cl((t-b[phase])/Math.max(.001,end-b[phase])));
 const profile=ramp(q,.115,.17),lift=ramp(q,.31,.405),chat=ramp(q,.49,.58),outro=ramp(q,.735,.815);
 const focus=ramp(q,.215,.30)*(1-lift);
 const pose={x:0,y:lerp(80,26,profile)+62*lift-24*chat-222*outro,scale:lerp(1.02,1.16,profile)-.32*lift+.10*chat-.40*outro,rotation:lerp(.035,.005,profile)-.13*lift+.125*chat+.09*outro};
 return {t,q,holdAt,pose,profile,lift,chat,outro};
}
function transformPoint(pose,x,y){const co=Math.cos(pose.rotation),si=Math.sin(pose.rotation);return {x:pose.x+pose.scale*(x*co-y*si),y:pose.y+pose.scale*(x*si+y*co)};}
function postArt(c,img,useProfile,x,y,size,t,accent,morph=0){art(c,img,x,y,size,t,accent);}
export function drawMotion(c,w,h,t,p,a,img){
 const useProfile=p.profileEnabled!==false&&realProfile;const handle=useProfile?'doublev4902':p.artist;
 const state=motionState(t,a);t=state.t;const {q,pose,profile,lift,chat,outro}=state;
 const scale=Math.min(w/600,h/1000), W=w/scale,H=h/scale,accent=p.style==='energy'?'#b9f27b':p.style==='cinema'?'#f3ba83':p.style==='minimal'?'#d8d6ef':(p.variant||0)%2?'#f1a5c9':'#bc9cff';const bass=a.bass[Math.floor((a.start+t)/.02)]||0;
 c.save();c.fillStyle='#000';c.fillRect(0,0,w,h);c.translate(w/2,h/2);c.scale(scale,scale);
 const glow=c.createRadialGradient(pose.x*.2,0,10,0,0,650);glow.addColorStop(0,'#292036');glow.addColorStop(.6,'#100d16');glow.addColorStop(1,'#050407');c.fillStyle=glow;c.fillRect(-W/2,-H/2,W,H);
 // The header and footer are outside the camera, in safe areas.
 fitted(c,p.artist.toUpperCase(),0,-H/2+95,420,16,'#d2d2d2');tx(c,'NOUVEAU MORCEAU',0,H/2-105,10,'#909090',500);
 const phoneScale=pose.scale,phoneY=pose.y,phoneRot=pose.rotation;
 // Kinetic heading, swept upward as the camera pushes into the UI.
 alpha(c,(1-ramp(q,.12,.19))*ramp(q,0,.035),()=>{c.translate(0,-350-ramp(q,.12,.19)*60);tx(c,'LE PROCHAIN',0,0,30,'#c9c9c9');tx(c,'CHAPITRE.',0,51,49,'#fff',800)});
 alpha(c,ramp(q,.30,.36)*(1-ramp(q,.48,.54)),()=>{c.translate(0,-365+(1-lift)*15);tx(c,'MONTE LE',0,0,31,accent);tx(c,'VOLUME.',0,52,60,'#fff',800)});
 alpha(c,ramp(q,.54,.6)*(1-ramp(q,.72,.78)),()=>{tx(c,'ÇA SORT QUAND ?',0,-330,31,'#fff',800)});
 // The phone settles at each action; the foreground card carries the transition.
 c.save();c.globalAlpha*=1-ramp(q,.755,.82);c.translate(pose.x,phoneY);c.rotate(phoneRot);c.scale(phoneScale,phoneScale);phoneBody(c);
 c.save();rect(c,-145,-291,290,582,30);c.clip();
 tx(c,'00:00',-121,-261,10,'#ddd',700,'left');tx(c,'▰',119,-261,11,'#eee');
 const searchOff=-profile*310;
 c.save();c.translate(searchOff,0);tx(c,'Rechercher',-122,-206,24,'#fff',700,'left');rect(c,-127,-177,254,43,11,'#292929');c.strokeStyle='#bcbcbc';c.lineWidth=2;c.beginPath();c.arc(-110,-158,6,0,Math.PI*2);c.moveTo(-106,-153);c.lineTo(-101,-148);c.stroke();const typed=handle.slice(0,Math.floor(cl((q-.025)/.085)*handle.length));fitted(c,typed,-3,-150,190,19);if(q<.12&&Math.floor(t*3)%2===0)rect(c,85,-165,1,20,0,accent);
 alpha(c,ramp(q,.075,.11),()=>{if(useProfile){c.save();c.beginPath();c.arc(-101,-79,25,0,Math.PI*2);c.clip();c.drawImage(realProfile.avatar,-126,-104,50,50);c.restore();}else art(c,img,-126,-104,50,t,accent);fitted(c,handle,30,-84,180,17,'#fff',700);tx(c,'Artiste · Musique',-63,-59,12,'#ccc',500,'left');rect(c,-127,-28,254,1,0,'#313131');tx(c,'Un nouveau son arrive.',-122,7,15,'#ddd',500,'left')});
 // Individually rising keyboard keys.
 const letters=['AZERTYUIOP','QSDFGHJKLM','WXCVBN'];letters.forEach((row,ri)=>[...row].forEach((ch,ci)=>{const sz=22,gap=4,xx=-row.length*26/2+ci*26;const intro=ramp(q,.01+ci*.001,.04+ci*.001);rect(c,xx,145+ri*35+(1-intro)*60,sz,29,4,'#313131');tx(c,ch,xx+11,165+ri*35+(1-intro)*60,11,'#ddd',500)}));c.restore();
 const contentOff=(1-profile)*310-chat*310;c.save();c.translate(contentOff,0);
 if(useProfile){
 fitted(c,'doublev4902',0,-212,239,22);tx(c,'⌄',113,-212,15,'#ddd');
 // Original screenshot geometry, images, buttons and grid. Only small text is refreshed.
 c.save();rect(c,-137,-192,274,437,0);c.clip();c.translate(-137,-192);c.scale(274/512,274/512);
 c.drawImage(realProfile.body,0,0);
 // Replace only the follower metric; blank means hidden.
 rect(c,279,43,114,55,0,'#0d1115');
 if(p.followers!==null&&p.followers!==undefined&&String(p.followers).trim()!==''&&/^\d{1,9}$/.test(String(p.followers))){fitted(c,Number(p.followers).toLocaleString('fr-FR'),338,66,100,21,'#eee',700);tx(c,'followers',288,89,17,'#eee',500,'left');}
 // Match the original lines and positions, with a modest increase in type size.
 rect(c,16,125,480,120,0,'#0d1115');
 tx(c,'Artiste',20,143,18,'#999',500,'left');tx(c,'DOUBLE-V',20,165,19,'#eee',500,'left');tx(c,'Artiste indépendant',20,187,19,'#eee',500,'left');tx(c,'Je fais du son pour moi.',20,209,19,'#eee',500,'left');
 tx(c,'↗',20,239,23,'#8697e8',500,'left');tx(c,'monlien.bio/double_v',49,238,19,'#8697e8',500,'left');
 c.restore();

 }else{
 fitted(c,p.artist,0,-211,230,23);art(c,img,-38,-182,76,t,accent);tx(c,'UN NOUVEAU CHAPITRE',0,-83,11,'#afafaf');rect(c,-118,-61,236,32,7,accent);tx(c,'Découvrir le morceau',0,-40,12,'#171717',700);
 const gridY=-8-ramp(q,.23,.32)*34;for(let j=0;j<6;j++){let xx=-125+(j%3)*85,yy=gridY+Math.floor(j/3)*85;art(c,img,xx,yy,79,t+j,accent);alpha(c,.22*j,()=>{rect(c,xx,yy,79,79,4,'#0a0a0a')})}
 tx(c,'PROCHAINE SORTIE',0,202,10,'#a8a8a8');wave(c,a,t,-115,233,230,17,accent);}
 // A fresh draft opens over the profile; no existing post is selected.
 const draft=ramp(q,.30,.35);
 alpha(c,draft,()=>{c.save();c.translate(0,(1-draft)*430);rect(c,-144,-199,288,465,20,'#000','#333');rect(c,-23,-188,46,3,2,'#666');tx(c,'Nouvelle publication',0,-153,18);tx(c,'+',115,-153,22);alpha(c,1-ramp(q,.35,.395),()=>art(c,img,-66,-116,132,t,accent));title(c,p.title,0,57,240,65,22);tx(c,'Un nouveau son arrive.',0,143,13,'#aaa',500);rect(c,-119,177,238,36,9,'#21172e',accent);tx(c,'PRÉPARER L’ANNONCE',0,200,11);c.restore();});
 c.restore();
 // Conversation slides in; each bubble has its own eased timing.
 c.save();c.translate((1-chat)*310,0);tx(c,'‹',-124,-210,28,accent);fitted(c,p.artist,0,-213,205,19);tx(c,'L’ANNONCE',0,-186,10,'#a5a5a5');
 const m1=ramp(q,.555,.59),m2=ramp(q,.61,.655),m3=ramp(q,.665,.705);
 alpha(c,m1,()=>{c.save();c.translate((1-m1)*-50,0);rect(c,-124,-139,199,52,16,'#292929');tx(c,'C’est pour quand ?',-24,-108,16,'#eee',500);c.restore()});
 alpha(c,m2,()=>{c.save();c.translate((1-m2)*60,0);rect(c,-100,-61,223,75,16,'#30203e',accent);tx(c,'LE RENDEZ-VOUS',11,-36,10,'#aaa');fitted(c,p.dateLabel,11,-6,195,17,'#fff');c.restore()});
 alpha(c,m3,()=>{postArt(c,img,useProfile,-124,44,92,t,accent,1);title(c,p.title,54,76,143,74,22);rect(c,-124,157,248,43,10,'#282828');wave(c,a,t,-109,179,215,18,accent)});c.restore();
 // Light reflected on the display.
 const reflection=c.createLinearGradient(-150,-290,150,290);reflection.addColorStop(0,'#ffffff0c');reflection.addColorStop(.5,'#ffffff00');reflection.addColorStop(1,'#ffffff03');rect(c,-145,-291,290,582,30,reflection);c.restore();rect(c,-44,-280,88,20,11,'#040404');rect(c,-44,276,88,4,2,'#bdbdbd');c.restore();
 // One continuous card path: the new draft -> foreground -> message attachment.
 const up=ramp(q,.35,.415),back=ramp(q,.49,.585);
 if(q>=.35&&q<.685){
 const sourceX=0;
 const sourceY=-50;
 const start=transformPoint(pose,sourceX,sourceY),destination=transformPoint(pose,-78,90);
 const heroX=lerp(start.x,0,up),heroY=lerp(start.y,-15,up);
 const x=lerp(heroX,destination.x,back),y=lerp(heroY,destination.y,back);
 const sz=lerp(lerp(132*phoneScale,315,up),92*phoneScale,back);
 const rotation=lerp(lerp(phoneRot,-.035,up),phoneRot,back),depth=up*(1-back);
 alpha(c,1-ramp(q,.665,.685),()=>{c.save();c.translate(x,y);c.rotate(rotation);
 const velocity=4*up*(1-up)+4*back*(1-back);c.filter=velocity>.05?`blur(${velocity*.55*scale}px)`:'none';
 c.shadowColor='#000b';c.shadowBlur=12+34*depth;c.shadowOffsetX=depth*8;c.shadowOffsetY=8+24*depth;
 rect(c,-sz/2,-sz/2,sz,sz,10,'#171717','#666666');c.shadowBlur=0;c.shadowOffsetY=0;c.shadowOffsetX=0;
 postArt(c,img,useProfile,-sz/2,-sz/2,sz,t,accent,ramp(q,.405,.445));
 const sheen=c.createLinearGradient(-sz/2,-sz/2,sz/2,sz/2);sheen.addColorStop(0,'#ffffff17');sheen.addColorStop(.35,'#ffffff00');sheen.addColorStop(1,'#ffffff08');rect(c,-sz/2,-sz/2,sz,sz,8,sheen);
 alpha(c,depth*ramp(q,.415,.44),()=>{rect(c,-sz/2,sz/2+12,sz,49,9,'#202020');fitted(c,p.title,0,sz/2+42,sz-24,18);});
 c.restore();});
 }
 // The attachment becomes the final cover while the phone recedes.
 if(q>=.735){const arrival=ramp(q,.735,.82),start=transformPoint(pose,-78,90),sz=lerp(92*phoneScale,228,arrival);
 c.save();c.translate(lerp(start.x,0,arrival),lerp(start.y,-151,arrival));c.rotate(phoneRot*(1-arrival));
 c.shadowColor='#0009';c.shadowBlur=25;c.shadowOffsetY=18;rect(c,-sz/2,-sz/2,sz,sz,10,'#171717','#666666');c.shadowBlur=0;c.shadowOffsetY=0;
 postArt(c,img,useProfile,-sz/2,-sz/2,sz,t,accent,1);c.restore();}
 // End card holds, never fades away before the last frame.
 const reveal=ramp(q,.76,.82);alpha(c,reveal,()=>{c.save();c.translate(0,(1-reveal)*35);const impactScale=1+.025*Math.sin(Math.PI*reveal);c.scale(impactScale,impactScale);rect(c,-112,61,224,28,14,'#241831',accent);tx(c,p.releasePast?'DISPONIBLE MAINTENANT':'NOUVELLE SORTIE',0,80,10,'#fff');title(c,p.title,0,143,510,155,57);tx(c,p.releasePast?'À ÉCOUTER':'DISPONIBLE LE',0,322,12,'#a9a9a9',500);fitted(c,p.dateLabel,0,359,500,31,'#fff');c.restore()});
 c.restore();
}
