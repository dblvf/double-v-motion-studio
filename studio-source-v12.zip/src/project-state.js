export const ENGINE_VERSION=4;
export function restoredSettings(item){const legacy=(item.p.engineVersion||1)<ENGINE_VERSION;return {legacy,p:{...item.p,engineVersion:ENGINE_VERSION},scenes:legacy?null:item.scenes,customScenes:!legacy};}
